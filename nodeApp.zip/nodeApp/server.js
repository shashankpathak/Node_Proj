const express =require('express');
var mysql = require('mysql');
var app = express();
var bodyParser = require('body-parser');

var connection =mysql.createConnection({
    //properties...
    host:'localhost',
    user:'root',
    password:'',
    database:'demodb'
});

connection.connect(function(error){
    if(!!error){
        console.log('Error connecting to DataBase...');
    } else{
    console.log('Connected to DataBase..');
    }
});

app.use(bodyParser.json());

app.get('/employees',function(req,res){
    connection.query('select * from employee',function(error,rows){
        if(!!error){
            console.log('error in query');
        }
        else{
            console.log('Success! \n');
            console.log(rows);
            res.end(JSON.stringify(rows));
        }
    });
});


app.post('/newemployee', function (req, res) {
    var postData  = req.body;
    connection.query('INSERT INTO employee SET ?', postData, function (error, results) {
       if (!!error) {
           console.log('error in query');
    }
    else{
        res.end(JSON.stringify(results));
        console.log('Last inserted id:', results.insertId);
    }
     });
 });

 app.put('/updatedata', function(req,res){
     connection.query('UPDATE employee SET name=?,salary=? where id=?',[req.body.name,req.body.salary, req.body.id] , function(error,results){
         if(!!error){
             console.log('error in query');
         }
         else{
             res.end(JSON.stringify(results));
             console.log('Employee data updated successfully!!');
         }
     });
 });

 app.delete('/deletedata',function(req,res){
     connection.query('DELETE from employee where id=?',[req.body.id],function(error, results){
        if(!!error){
            console.log('error in query');
        }
        else{
            res.end(JSON.stringify(results));
            console.log('Employee data deleted successfully!!');
        }
     });
 });

app.listen(8000, ()=>console.log('server running on http://localhost:8000/'));

